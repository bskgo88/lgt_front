export default function AudienceAcquisition() {
  return <div className="SetTDB">Audience Acquisition Page</div>;
}