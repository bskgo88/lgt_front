export default function AudienceAnalytics() {
  return <div className="SetTDB">Audience Analytics Page</div>;
}