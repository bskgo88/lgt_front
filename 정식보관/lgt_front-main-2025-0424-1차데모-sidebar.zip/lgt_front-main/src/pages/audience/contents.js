export default function AudienceContents() {
  return <div className="SetTDB">Audience Contents Page</div>;
}