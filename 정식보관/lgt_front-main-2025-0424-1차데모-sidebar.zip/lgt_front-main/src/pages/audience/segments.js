export default function AudienceSegments() {
  return <div className="SetTDB">Audience Segments Page</div>;
}