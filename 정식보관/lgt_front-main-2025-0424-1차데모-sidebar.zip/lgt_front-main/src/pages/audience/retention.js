export default function AudienceRetention() {
  return <div className="SetTDB">Audience Retention Page</div>;
}