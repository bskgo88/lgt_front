export default function VideoTrends() {
  return <div className="SetTDB">Video Trends Page</div>;
}