import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar
} from "recharts";
import {
  Box,
  Typography,
  IconButton,
  Divider,
  MenuItem,
  Select,
  Paper,
  Grid
} from "@mui/material";
import { Download, FilterList } from "@mui/icons-material";

const COLORS = ["#f97316", "#60a5fa", "#34d399", "#c084fc"];

const dummyLineData = [
  { date: "08.28", UD: 50, Duration: 120, Access: 30 },
  { date: "08.29", UD: 180, Duration: 230, Access: 100 },
  { date: "08.30", UD: 500, Duration: 460, Access: 160 },
  { date: "08.31", UD: 400, Duration: 540, Access: 200 },
  { date: "09.01", UD: 700, Duration: 590, Access: 300 },
  { date: "09.02", UD: 600, Duration: 580, Access: 400 },
  { date: "09.03", UD: 550, Duration: 620, Access: 350 }
];

const dummyPieData = [
  { name: "webOS 3.0", value: 300 },
  { name: "webOS 22", value: 200 }
];

const dummyDeviceData = [
  { name: "LG TV", value: 100 },
  { name: "Unknown", value: 900 }
];
export default function OverviewPage() {
  return <div className="SetTDB">Overview Page</div>;
}
