export default function Settings() {
  return <div className="SetTDB">Settings Page</div>;
}